import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import path from 'path'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(),tailwindcss()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  server: {
    host: true,
    allowedHosts: ['5173-i34fq2qlzs5rz7pif66p6-970edbc8.manusvm.computer', '5174-i34fq2qlzs5rz7pif66p6-970edbc8.manusvm.computer']
  }
})
