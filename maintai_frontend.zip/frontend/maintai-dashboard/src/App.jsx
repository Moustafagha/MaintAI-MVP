import { useState, useEffect, useRef } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Thermometer, Activity, Gauge, RefreshCw, AlertTriangle, CheckCircle, AlertCircle, Brain } from 'lucide-react'
import { useTranslation } from './hooks/useTranslation'
import LanguageSelector from './components/LanguageSelector'
import AIInsights from './components/AIInsights'
import NLPAssistant from './components/NLPAssistant'
import './App.css'

function App() {
  const [sensorData, setSensorData] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [lastUpdated, setLastUpdated] = useState(null)
  const [highContrast, setHighContrast] = useState(false)
  const [activeTab, setActiveTab] = useState('sensors')
  const liveRegionRef = useRef(null)
  const { t, isRTL } = useTranslation()

  // Backend API URL - will be updated when backend is deployed
  const API_URL = 'https://vgh0i1cj398e.manus.space/api/sensors'

  const fetchSensorData = async () => {
    setLoading(true)
    setError(null)
    try {
      const response = await fetch(API_URL)
      if (!response.ok) {
        throw new Error(t('errors.loadingError'))
      }
      const data = await response.json()
      setSensorData(data)
      setLastUpdated(new Date())
      
      // Announce update to screen readers
      if (liveRegionRef.current) {
        liveRegionRef.current.textContent = `${t('dashboard.lastUpdated')}: ${new Date().toLocaleTimeString()}`
      }
    } catch (err) {
      setError(err.message)
      if (liveRegionRef.current) {
        liveRegionRef.current.textContent = `${t('errors.fetchError')} ${err.message}`
      }
    } finally {
      setLoading(false)
    }
  }

  // Auto-refresh every 5 seconds
  useEffect(() => {
    fetchSensorData()
    const interval = setInterval(fetchSensorData, 5000)
    return () => clearInterval(interval)
  }, [])

  // Keyboard event handler for refresh button
  const handleKeyPress = (event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault()
      fetchSensorData()
    }
  }

  const getTemperatureStatus = (temp, aiAnalysis) => {
    // Enhanced status with AI insights
    const baseStatus = getBaseTemperatureStatus(temp)
    
    if (aiAnalysis?.anomaly_detection?.is_anomaly) {
      return {
        ...baseStatus,
        status: 'AI Alert',
        color: highContrast ? 'bg-purple-800 text-white' : 'bg-purple-500 text-white',
        icon: Brain,
        ariaLabel: `Temperature ${temp} degrees Celsius - AI anomaly detected`
      }
    }
    
    return baseStatus
  }

  const getBaseTemperatureStatus = (temp) => {
    if (temp < 30) return { 
      status: t('status.normal'), 
      color: highContrast ? 'bg-green-700 text-white' : 'bg-green-500 text-white',
      icon: CheckCircle,
      ariaLabel: t('status.temperatureStatus', { value: temp, status: t('status.normal') })
    }
    if (temp < 60) return { 
      status: t('status.warning'), 
      color: highContrast ? 'bg-yellow-700 text-white' : 'bg-yellow-500 text-white',
      icon: AlertTriangle,
      ariaLabel: t('status.temperatureStatus', { value: temp, status: t('status.warning') })
    }
    return { 
      status: t('status.critical'), 
      color: highContrast ? 'bg-red-800 text-white' : 'bg-red-500 text-white',
      icon: AlertCircle,
      ariaLabel: t('status.temperatureStatus', { value: temp, status: t('status.critical') })
    }
  }

  const getVibrationStatus = (vib, aiAnalysis) => {
    const baseStatus = getBaseVibrationStatus(vib)
    
    if (aiAnalysis?.anomaly_detection?.is_anomaly) {
      return {
        ...baseStatus,
        status: 'AI Alert',
        color: highContrast ? 'bg-purple-800 text-white' : 'bg-purple-500 text-white',
        icon: Brain,
        ariaLabel: `Vibration ${vib} g - AI anomaly detected`
      }
    }
    
    return baseStatus
  }

  const getBaseVibrationStatus = (vib) => {
    if (vib < 0.5) return { 
      status: t('status.normal'), 
      color: highContrast ? 'bg-green-700 text-white' : 'bg-green-500 text-white',
      icon: CheckCircle,
      ariaLabel: t('status.vibrationStatus', { value: vib, status: t('status.normal') })
    }
    if (vib < 1.0) return { 
      status: t('status.warning'), 
      color: highContrast ? 'bg-yellow-700 text-white' : 'bg-yellow-500 text-white',
      icon: AlertTriangle,
      ariaLabel: t('status.vibrationStatus', { value: vib, status: t('status.warning') })
    }
    return { 
      status: t('status.critical'), 
      color: highContrast ? 'bg-red-800 text-white' : 'bg-red-500 text-white',
      icon: AlertCircle,
      ariaLabel: t('status.vibrationStatus', { value: vib, status: t('status.critical') })
    }
  }

  const getPressureStatus = (pres, aiAnalysis) => {
    const baseStatus = getBasePressureStatus(pres)
    
    if (aiAnalysis?.anomaly_detection?.is_anomaly) {
      return {
        ...baseStatus,
        status: 'AI Alert',
        color: highContrast ? 'bg-purple-800 text-white' : 'bg-purple-500 text-white',
        icon: Brain,
        ariaLabel: `Pressure ${pres} bar - AI anomaly detected`
      }
    }
    
    return baseStatus
  }

  const getBasePressureStatus = (pres) => {
    if (pres < 2.0) return { 
      status: t('status.normal'), 
      color: highContrast ? 'bg-green-700 text-white' : 'bg-green-500 text-white',
      icon: CheckCircle,
      ariaLabel: t('status.pressureStatus', { value: pres, status: t('status.normal') })
    }
    if (pres < 4.0) return { 
      status: t('status.warning'), 
      color: highContrast ? 'bg-yellow-700 text-white' : 'bg-yellow-500 text-white',
      icon: AlertTriangle,
      ariaLabel: t('status.pressureStatus', { value: pres, status: t('status.warning') })
    }
    return { 
      status: t('status.critical'), 
      color: highContrast ? 'bg-red-800 text-white' : 'bg-red-500 text-white',
      icon: AlertCircle,
      ariaLabel: t('status.pressureStatus', { value: pres, status: t('status.critical') })
    }
  }

  return (
    <div className={`min-h-screen p-6 ${highContrast ? 'bg-black text-white' : 'bg-gray-50'} ${isRTL ? 'rtl' : 'ltr'}`}>
      {/* Skip to main content link for screen readers */}
      <a 
        href="#main-content" 
        className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 bg-blue-600 text-white px-4 py-2 rounded z-50"
      >
        {t('dashboard.skipToMain')}
      </a>

      {/* Live region for screen reader announcements */}
      <div 
        ref={liveRegionRef}
        aria-live="polite" 
        aria-atomic="true" 
        className="sr-only"
      ></div>

      <div className="max-w-7xl mx-auto">
        {/* Header section */}
        <header className="mb-8">
          <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <div>
              <h1 className={`text-4xl font-bold mb-2 ${highContrast ? 'text-white' : 'text-gray-900'}`}>
                {t('dashboard.title')}
              </h1>
              <p className={`text-lg ${highContrast ? 'text-gray-300' : 'text-gray-600'}`}>
                {t('dashboard.subtitle')}
              </p>
            </div>
            <LanguageSelector />
          </div>
          {lastUpdated && (
            <p className={`text-sm mt-2 ${highContrast ? 'text-gray-400' : 'text-gray-500'}`}>
              {t('dashboard.lastUpdated')}: {lastUpdated.toLocaleTimeString()}
            </p>
          )}
        </header>

        {/* Controls section */}
        <section className="mb-6" aria-label={t('dashboard.controls')}>
          <div className={`flex flex-wrap gap-4 items-center ${isRTL ? 'flex-row-reverse' : ''}`}>
            <Button 
              onClick={fetchSensorData} 
              onKeyDown={handleKeyPress}
              disabled={loading}
              className="flex items-center gap-2"
              aria-label={loading ? t('buttons.refreshingAriaLabel') : t('buttons.refreshAriaLabel')}
            >
              <RefreshCw 
                className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} 
                aria-hidden="true"
              />
              {loading ? t('buttons.refreshing') : t('buttons.refresh')}
            </Button>
            
            <Button
              onClick={() => setHighContrast(!highContrast)}
              variant="outline"
              className={highContrast ? 'border-white text-white hover:bg-gray-800' : ''}
              aria-label={highContrast ? t('buttons.disableHighContrast') : t('buttons.enableHighContrast')}
            >
              {highContrast ? t('buttons.normalContrast') : t('buttons.highContrast')}
            </Button>
          </div>
        </section>

        {/* Error message */}
        {error && (
          <div 
            className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg"
            role="alert"
            aria-live="assertive"
          >
            <p className="text-red-800">
              <strong>{t('errors.fetchError')}</strong> {error}
            </p>
          </div>
        )}

        {/* Main content with tabs */}
        <main id="main-content">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className={`grid w-full grid-cols-3 ${highContrast ? 'bg-gray-800' : ''}`}>
              <TabsTrigger value="sensors" className={highContrast ? 'text-white data-[state=active]:bg-gray-700' : ''}>
                Sensor Data
              </TabsTrigger>
              <TabsTrigger value="ai" className={highContrast ? 'text-white data-[state=active]:bg-gray-700' : ''}>
                AI Insights
              </TabsTrigger>
              <TabsTrigger value="assistant" className={highContrast ? 'text-white data-[state=active]:bg-gray-700' : ''}>
                AI Assistant
              </TabsTrigger>
            </TabsList>

            {/* Sensor Data Tab */}
            <TabsContent value="sensors" className="space-y-6">
              {sensorData && (
                <section aria-label={t('dashboard.sensorReadings')}>
                  <h2 className="sr-only">{t('dashboard.sensorReadings')}</h2>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* Temperature Card */}
                    <Card className={highContrast ? 'bg-gray-900 border-gray-700' : ''}>
                      <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <CardTitle className={`text-sm font-medium ${highContrast ? 'text-white' : ''}`}>
                          {t('sensors.temperature')}
                        </CardTitle>
                        <Thermometer 
                          className={`h-4 w-4 ${highContrast ? 'text-gray-300' : 'text-muted-foreground'}`} 
                          aria-hidden="true"
                        />
                      </CardHeader>
                      <CardContent>
                        <div 
                          className={`text-2xl font-bold ${highContrast ? 'text-white' : ''}`}
                          aria-label={t('sensors.temperatureReading', { value: sensorData.temperature })}
                        >
                          {sensorData.temperature}°C
                        </div>
                        <div className={`flex items-center gap-2 mt-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                          {(() => {
                            const status = getTemperatureStatus(sensorData.temperature, sensorData.ai_analysis)
                            const IconComponent = status.icon
                            return (
                              <Badge 
                                className={status.color}
                                aria-label={status.ariaLabel}
                              >
                                <IconComponent className={`h-3 w-3 ${isRTL ? 'ml-1' : 'mr-1'}`} aria-hidden="true" />
                                {status.status}
                              </Badge>
                            )
                          })()}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Vibration Card */}
                    <Card className={highContrast ? 'bg-gray-900 border-gray-700' : ''}>
                      <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <CardTitle className={`text-sm font-medium ${highContrast ? 'text-white' : ''}`}>
                          {t('sensors.vibration')}
                        </CardTitle>
                        <Activity 
                          className={`h-4 w-4 ${highContrast ? 'text-gray-300' : 'text-muted-foreground'}`} 
                          aria-hidden="true"
                        />
                      </CardHeader>
                      <CardContent>
                        <div 
                          className={`text-2xl font-bold ${highContrast ? 'text-white' : ''}`}
                          aria-label={t('sensors.vibrationReading', { value: sensorData.vibration })}
                        >
                          {sensorData.vibration} g
                        </div>
                        <div className={`flex items-center gap-2 mt-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                          {(() => {
                            const status = getVibrationStatus(sensorData.vibration, sensorData.ai_analysis)
                            const IconComponent = status.icon
                            return (
                              <Badge 
                                className={status.color}
                                aria-label={status.ariaLabel}
                              >
                                <IconComponent className={`h-3 w-3 ${isRTL ? 'ml-1' : 'mr-1'}`} aria-hidden="true" />
                                {status.status}
                              </Badge>
                            )
                          })()}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Pressure Card */}
                    <Card className={highContrast ? 'bg-gray-900 border-gray-700' : ''}>
                      <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <CardTitle className={`text-sm font-medium ${highContrast ? 'text-white' : ''}`}>
                          {t('sensors.pressure')}
                        </CardTitle>
                        <Gauge 
                          className={`h-4 w-4 ${highContrast ? 'text-gray-300' : 'text-muted-foreground'}`} 
                          aria-hidden="true"
                        />
                      </CardHeader>
                      <CardContent>
                        <div 
                          className={`text-2xl font-bold ${highContrast ? 'text-white' : ''}`}
                          aria-label={t('sensors.pressureReading', { value: sensorData.pressure })}
                        >
                          {sensorData.pressure} bar
                        </div>
                        <div className={`flex items-center gap-2 mt-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                          {(() => {
                            const status = getPressureStatus(sensorData.pressure, sensorData.ai_analysis)
                            const IconComponent = status.icon
                            return (
                              <Badge 
                                className={status.color}
                                aria-label={status.ariaLabel}
                              >
                                <IconComponent className={`h-3 w-3 ${isRTL ? 'ml-1' : 'mr-1'}`} aria-hidden="true" />
                                {status.status}
                              </Badge>
                            )
                          })()}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </section>
              )}

              {/* System Status */}
              <section aria-label={t('dashboard.systemStatus')}>
                <Card className={highContrast ? 'bg-gray-900 border-gray-700' : ''}>
                  <CardHeader>
                    <CardTitle className={highContrast ? 'text-white' : ''}>
                      {t('systemInfo.title')}
                    </CardTitle>
                    <CardDescription className={highContrast ? 'text-gray-300' : ''}>
                      {t('systemInfo.description')}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {sensorData ? (
                      <div className="space-y-4">
                        <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                          <span className={`font-medium ${highContrast ? 'text-white' : ''}`}>
                            {t('systemInfo.overallStatus')}
                          </span>
                          <Badge 
                            className={highContrast ? 'bg-green-700 text-white' : 'bg-green-500 text-white'}
                            aria-label={t('status.systemStatus', { status: t('status.operational') })}
                          >
                            <CheckCircle className={`h-3 w-3 ${isRTL ? 'ml-1' : 'mr-1'}`} aria-hidden="true" />
                            {t('status.operational')}
                          </Badge>
                        </div>
                        <div className={`text-sm ${highContrast ? 'text-gray-300' : 'text-gray-600'}`}>
                          <ul className="space-y-1" role="list">
                            <li>• {t('systemInfo.sensorsNormal')}</li>
                            <li>• {t('systemInfo.noMaintenance')}</li>
                            <li>• {t('systemInfo.nextMaintenance')}</li>
                          </ul>
                        </div>
                      </div>
                    ) : (
                      <p className={`${highContrast ? 'text-gray-400' : 'text-gray-500'}`}>
                        {t('systemInfo.loading')}
                      </p>
                    )}
                  </CardContent>
                </Card>
              </section>
            </TabsContent>

            {/* AI Insights Tab */}
            <TabsContent value="ai">
              <AIInsights 
                aiAnalysis={sensorData?.ai_analysis} 
                highContrast={highContrast}
                isRTL={isRTL}
              />
            </TabsContent>

            {/* NLP Assistant Tab */}
            <TabsContent value="assistant">
              <NLPAssistant 
                highContrast={highContrast}
                isRTL={isRTL}
              />
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  )
}

export default App

