import { createContext, useContext, useState, useEffect } from 'react'
import enTranslations from '../locales/en.json'
import frTranslations from '../locales/fr.json'
import arTranslations from '../locales/ar.json'

const translations = {
  en: enTranslations,
  fr: frTranslations,
  ar: arTranslations
}

const LanguageContext = createContext()

export const useTranslation = () => {
  const context = useContext(LanguageContext)
  if (!context) {
    throw new Error('useTranslation must be used within a LanguageProvider')
  }
  return context
}

export const LanguageProvider = ({ children }) => {
  const [currentLanguage, setCurrentLanguage] = useState('en')
  const [isRTL, setIsRTL] = useState(false)

  useEffect(() => {
    // Check for saved language preference
    const savedLanguage = localStorage.getItem('maintai-language')
    if (savedLanguage && translations[savedLanguage]) {
      setCurrentLanguage(savedLanguage)
    }
  }, [])

  useEffect(() => {
    // Update RTL status and document direction
    const rtlLanguages = ['ar']
    const isRightToLeft = rtlLanguages.includes(currentLanguage)
    setIsRTL(isRightToLeft)
    
    // Update document direction and language
    document.documentElement.dir = isRightToLeft ? 'rtl' : 'ltr'
    document.documentElement.lang = currentLanguage
    
    // Save language preference
    localStorage.setItem('maintai-language', currentLanguage)
  }, [currentLanguage])

  const t = (key, variables = {}) => {
    const keys = key.split('.')
    let value = translations[currentLanguage]
    
    for (const k of keys) {
      value = value?.[k]
    }
    
    if (!value) {
      // Fallback to English if translation not found
      value = translations.en
      for (const k of keys) {
        value = value?.[k]
      }
    }
    
    if (!value) {
      return key // Return key if no translation found
    }
    
    // Replace variables in the translation
    return Object.keys(variables).reduce((str, variable) => {
      return str.replace(new RegExp(`{{${variable}}}`, 'g'), variables[variable])
    }, value)
  }

  const changeLanguage = (language) => {
    if (translations[language]) {
      setCurrentLanguage(language)
    }
  }

  const value = {
    currentLanguage,
    isRTL,
    t,
    changeLanguage,
    availableLanguages: Object.keys(translations)
  }

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  )
}

