import { useState, useRef, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { ScrollArea } from '@/components/ui/scroll-area.jsx'
import { MessageCircle, Send, Bot, User, Lightbulb, HelpCircle } from 'lucide-react'
import { useTranslation } from '../hooks/useTranslation'

const NLPAssistant = ({ highContrast, isRTL }) => {
  const [messages, setMessages] = useState([])
  const [inputValue, setInputValue] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [suggestions, setSuggestions] = useState([])
  const [showSuggestions, setShowSuggestions] = useState(true)
  const messagesEndRef = useRef(null)
  const inputRef = useRef(null)
  const { t } = useTranslation()

  // Backend API URL
  const API_URL = 'https://vgh0i1cj398e.manus.space/api'

  useEffect(() => {
    // Load suggestions on component mount
    loadSuggestions()
    
    // Add welcome message
    setMessages([{
      id: 1,
      type: 'assistant',
      content: 'Hello! I\'m your MaintAI assistant. I can help you understand the monitoring system, sensor readings, AI insights, and maintenance recommendations. What would you like to know?',
      timestamp: new Date().toISOString(),
      intent: 'greeting',
      confidence: 1.0
    }])
  }, [])

  useEffect(() => {
    // Scroll to bottom when new messages are added
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  const loadSuggestions = async () => {
    try {
      const response = await fetch(`${API_URL}/suggestions`)
      if (response.ok) {
        const data = await response.json()
        setSuggestions(data.suggestions || [])
      }
    } catch (error) {
      console.error('Error loading suggestions:', error)
    }
  }

  const sendMessage = async (message = inputValue.trim()) => {
    if (!message) return

    const userMessage = {
      id: Date.now(),
      type: 'user',
      content: message,
      timestamp: new Date().toISOString()
    }

    setMessages(prev => [...prev, userMessage])
    setInputValue('')
    setIsLoading(true)
    setShowSuggestions(false)

    try {
      const response = await fetch(`${API_URL}/ask`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ question: message })
      })

      if (response.ok) {
        const data = await response.json()
        
        const assistantMessage = {
          id: Date.now() + 1,
          type: 'assistant',
          content: data.response,
          timestamp: data.timestamp,
          intent: data.intent,
          confidence: data.confidence,
          hasContext: data.has_context
        }

        setMessages(prev => [...prev, assistantMessage])
      } else {
        throw new Error('Failed to get response')
      }
    } catch (error) {
      console.error('Error sending message:', error)
      
      const errorMessage = {
        id: Date.now() + 1,
        type: 'assistant',
        content: 'I\'m sorry, I\'m having trouble connecting right now. Please try again later.',
        timestamp: new Date().toISOString(),
        intent: 'error',
        confidence: 0.0
      }

      setMessages(prev => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const handleKeyPress = (event) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault()
      sendMessage()
    }
  }

  const handleSuggestionClick = (suggestion) => {
    sendMessage(suggestion)
  }

  const clearChat = () => {
    setMessages([{
      id: 1,
      type: 'assistant',
      content: 'Chat cleared! How can I help you today?',
      timestamp: new Date().toISOString(),
      intent: 'greeting',
      confidence: 1.0
    }])
    setShowSuggestions(true)
  }

  const getConfidenceColor = (confidence) => {
    if (confidence >= 0.8) return highContrast ? 'bg-green-700' : 'bg-green-500'
    if (confidence >= 0.6) return highContrast ? 'bg-yellow-700' : 'bg-yellow-500'
    return highContrast ? 'bg-red-800' : 'bg-red-500'
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className={highContrast ? 'bg-gray-900 border-gray-700' : ''}>
        <CardHeader>
          <CardTitle className={`flex items-center gap-2 ${highContrast ? 'text-white' : ''} ${isRTL ? 'flex-row-reverse' : ''}`}>
            <Bot className="h-5 w-5" aria-hidden="true" />
            AI Assistant
          </CardTitle>
          <CardDescription className={highContrast ? 'text-gray-300' : ''}>
            Ask questions about the monitoring system, sensors, and maintenance
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Chat Interface */}
      <Card className={`h-[600px] flex flex-col ${highContrast ? 'bg-gray-900 border-gray-700' : ''}`}>
        {/* Messages Area */}
        <CardContent className="flex-1 p-4">
          <ScrollArea className="h-full pr-4">
            <div className="space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex gap-3 ${message.type === 'user' ? (isRTL ? 'flex-row' : 'flex-row-reverse') : (isRTL ? 'flex-row-reverse' : 'flex-row')}`}
                >
                  {/* Avatar */}
                  <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                    message.type === 'user' 
                      ? (highContrast ? 'bg-blue-700' : 'bg-blue-500')
                      : (highContrast ? 'bg-gray-700' : 'bg-gray-200')
                  }`}>
                    {message.type === 'user' ? (
                      <User className="h-4 w-4 text-white" aria-hidden="true" />
                    ) : (
                      <Bot className={`h-4 w-4 ${highContrast ? 'text-white' : 'text-gray-600'}`} aria-hidden="true" />
                    )}
                  </div>

                  {/* Message Content */}
                  <div className={`flex-1 max-w-[80%] ${message.type === 'user' ? (isRTL ? 'text-right' : 'text-left') : (isRTL ? 'text-left' : 'text-right')}`}>
                    <div className={`rounded-lg p-3 ${
                      message.type === 'user'
                        ? (highContrast ? 'bg-blue-800 text-white' : 'bg-blue-500 text-white')
                        : (highContrast ? 'bg-gray-800 text-white border border-gray-600' : 'bg-gray-100 text-gray-900')
                    }`}>
                      <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                    </div>

                    {/* Message metadata for assistant messages */}
                    {message.type === 'assistant' && message.confidence !== undefined && (
                      <div className={`flex items-center gap-2 mt-1 text-xs ${isRTL ? 'flex-row-reverse' : 'flex-row'} ${highContrast ? 'text-gray-400' : 'text-gray-500'}`}>
                        <Badge 
                          className={`${getConfidenceColor(message.confidence)} text-white text-xs`}
                          aria-label={`Response confidence: ${Math.round(message.confidence * 100)} percent`}
                        >
                          {Math.round(message.confidence * 100)}%
                        </Badge>
                        {message.intent && (
                          <span className="capitalize">{message.intent.replace('_', ' ')}</span>
                        )}
                        {message.hasContext && (
                          <span className="text-green-600">• Live data</span>
                        )}
                      </div>
                    )}

                    <div className={`text-xs mt-1 ${highContrast ? 'text-gray-400' : 'text-gray-500'}`}>
                      {new Date(message.timestamp).toLocaleTimeString()}
                    </div>
                  </div>
                </div>
              ))}

              {/* Loading indicator */}
              {isLoading && (
                <div className={`flex gap-3 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
                  <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${highContrast ? 'bg-gray-700' : 'bg-gray-200'}`}>
                    <Bot className={`h-4 w-4 ${highContrast ? 'text-white' : 'text-gray-600'}`} aria-hidden="true" />
                  </div>
                  <div className={`rounded-lg p-3 ${highContrast ? 'bg-gray-800 text-white border border-gray-600' : 'bg-gray-100 text-gray-900'}`}>
                    <div className="flex items-center gap-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>
        </CardContent>

        {/* Suggestions */}
        {showSuggestions && suggestions.length > 0 && (
          <div className="px-4 pb-2">
            <div className={`flex items-center gap-2 mb-2 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
              <Lightbulb className={`h-4 w-4 ${highContrast ? 'text-yellow-400' : 'text-yellow-500'}`} aria-hidden="true" />
              <span className={`text-sm font-medium ${highContrast ? 'text-white' : 'text-gray-700'}`}>
                Suggested Questions:
              </span>
            </div>
            <div className="flex flex-wrap gap-2">
              {suggestions.slice(0, 4).map((suggestion, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  onClick={() => handleSuggestionClick(suggestion)}
                  className={`text-xs ${highContrast ? 'border-gray-600 text-white hover:bg-gray-800' : ''}`}
                >
                  {suggestion}
                </Button>
              ))}
            </div>
          </div>
        )}

        {/* Input Area */}
        <div className={`border-t p-4 ${highContrast ? 'border-gray-600' : 'border-gray-200'}`}>
          <div className={`flex gap-2 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
            <Input
              ref={inputRef}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask me anything about the system..."
              disabled={isLoading}
              className={`flex-1 ${highContrast ? 'bg-gray-800 border-gray-600 text-white' : ''}`}
              aria-label="Type your question here"
            />
            <Button
              onClick={() => sendMessage()}
              disabled={isLoading || !inputValue.trim()}
              className="flex items-center gap-2"
              aria-label="Send message"
            >
              <Send className="h-4 w-4" aria-hidden="true" />
            </Button>
            <Button
              onClick={clearChat}
              variant="outline"
              className={highContrast ? 'border-gray-600 text-white hover:bg-gray-800' : ''}
              aria-label="Clear chat"
            >
              Clear
            </Button>
          </div>
        </div>
      </Card>
    </div>
  )
}

export default NLPAssistant

