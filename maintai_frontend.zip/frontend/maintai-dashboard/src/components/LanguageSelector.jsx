import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent } from '@/components/ui/card.jsx'
import { Globe, ChevronDown } from 'lucide-react'
import { useTranslation } from '../hooks/useTranslation'

const LanguageSelector = () => {
  const { currentLanguage, changeLanguage, t, isRTL } = useTranslation()
  const [isOpen, setIsOpen] = useState(false)

  const languages = [
    { code: 'en', name: 'English', nativeName: 'English' },
    { code: 'fr', name: 'French', nativeName: 'Français' },
    { code: 'ar', name: 'Arabic', nativeName: 'العربية' }
  ]

  const currentLang = languages.find(lang => lang.code === currentLanguage)

  const handleLanguageChange = (langCode) => {
    changeLanguage(langCode)
    setIsOpen(false)
  }

  const handleKeyDown = (event, langCode) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault()
      handleLanguageChange(langCode)
    }
  }

  return (
    <div className="relative">
      <Button
        variant="outline"
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}
        aria-label={t('languages.selectLanguage')}
        aria-expanded={isOpen}
        aria-haspopup="listbox"
      >
        <Globe className="h-4 w-4" aria-hidden="true" />
        <span>{currentLang?.nativeName}</span>
        <ChevronDown 
          className={`h-4 w-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} 
          aria-hidden="true"
        />
      </Button>

      {isOpen && (
        <Card className={`absolute top-full mt-2 z-50 min-w-[150px] ${isRTL ? 'right-0' : 'left-0'}`}>
          <CardContent className="p-2">
            <ul role="listbox" aria-label={t('languages.selectLanguage')}>
              {languages.map((language) => (
                <li key={language.code} role="option" aria-selected={currentLanguage === language.code}>
                  <button
                    className={`w-full text-left px-3 py-2 rounded hover:bg-gray-100 focus:bg-gray-100 focus:outline-none ${
                      currentLanguage === language.code ? 'bg-blue-50 font-medium' : ''
                    } ${isRTL ? 'text-right' : 'text-left'}`}
                    onClick={() => handleLanguageChange(language.code)}
                    onKeyDown={(e) => handleKeyDown(e, language.code)}
                    aria-label={`${t('languages.selectLanguage')}: ${language.nativeName}`}
                  >
                    <div className="flex items-center justify-between">
                      <span>{language.nativeName}</span>
                      {currentLanguage === language.code && (
                        <span className="text-blue-600 text-sm" aria-hidden="true">✓</span>
                      )}
                    </div>
                  </button>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {/* Overlay to close dropdown when clicking outside */}
      {isOpen && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setIsOpen(false)}
          aria-hidden="true"
        />
      )}
    </div>
  )
}

export default LanguageSelector

