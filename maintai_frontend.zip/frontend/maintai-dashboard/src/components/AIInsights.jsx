import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { AlertTriangle, CheckCircle, AlertCircle, Brain, TrendingUp, Wrench } from 'lucide-react'
import { useTranslation } from '../hooks/useTranslation'

const AIInsights = ({ aiAnalysis, highContrast, isRTL }) => {
  const { t } = useTranslation()

  if (!aiAnalysis) {
    return (
      <Card className={highContrast ? 'bg-gray-900 border-gray-700' : ''}>
        <CardHeader>
          <CardTitle className={`flex items-center gap-2 ${highContrast ? 'text-white' : ''} ${isRTL ? 'flex-row-reverse' : ''}`}>
            <Brain className="h-5 w-5" aria-hidden="true" />
            AI Analysis
          </CardTitle>
          <CardDescription className={highContrast ? 'text-gray-300' : ''}>
            Loading AI insights...
          </CardDescription>
        </CardHeader>
      </Card>
    )
  }

  const { anomaly_detection, maintenance_prediction, health_score } = aiAnalysis

  const getHealthScoreColor = (score) => {
    if (score >= 80) return highContrast ? 'bg-green-700' : 'bg-green-500'
    if (score >= 60) return highContrast ? 'bg-yellow-700' : 'bg-yellow-500'
    return highContrast ? 'bg-red-800' : 'bg-red-500'
  }

  const getPriorityIcon = (priority) => {
    switch (priority?.toLowerCase()) {
      case 'critical':
        return AlertCircle
      case 'high':
        return AlertTriangle
      case 'medium':
        return TrendingUp
      default:
        return CheckCircle
    }
  }

  const getPriorityColor = (priority) => {
    switch (priority?.toLowerCase()) {
      case 'critical':
        return highContrast ? 'bg-red-800 text-white' : 'bg-red-500 text-white'
      case 'high':
        return highContrast ? 'bg-orange-700 text-white' : 'bg-orange-500 text-white'
      case 'medium':
        return highContrast ? 'bg-yellow-700 text-white' : 'bg-yellow-500 text-white'
      default:
        return highContrast ? 'bg-green-700 text-white' : 'bg-green-500 text-white'
    }
  }

  return (
    <div className="space-y-6">
      {/* AI Analysis Header */}
      <Card className={highContrast ? 'bg-gray-900 border-gray-700' : ''}>
        <CardHeader>
          <CardTitle className={`flex items-center gap-2 ${highContrast ? 'text-white' : ''} ${isRTL ? 'flex-row-reverse' : ''}`}>
            <Brain className="h-5 w-5" aria-hidden="true" />
            AI Analysis & Insights
          </CardTitle>
          <CardDescription className={highContrast ? 'text-gray-300' : ''}>
            Real-time AI-powered equipment analysis and predictions
          </CardDescription>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* System Health Score */}
        <Card className={highContrast ? 'bg-gray-900 border-gray-700' : ''}>
          <CardHeader>
            <CardTitle className={`text-lg ${highContrast ? 'text-white' : ''}`}>
              System Health Score
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className={`text-3xl font-bold ${highContrast ? 'text-white' : ''}`}>
                {health_score}%
              </div>
              <Progress 
                value={health_score} 
                className="h-3"
                aria-label={`System health score: ${health_score} percent`}
              />
              <div className={`text-sm ${highContrast ? 'text-gray-300' : 'text-gray-600'}`}>
                {health_score >= 80 && "Excellent system health"}
                {health_score >= 60 && health_score < 80 && "Good system health"}
                {health_score >= 40 && health_score < 60 && "Fair system health - monitoring recommended"}
                {health_score < 40 && "Poor system health - immediate attention required"}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Anomaly Detection */}
        <Card className={highContrast ? 'bg-gray-900 border-gray-700' : ''}>
          <CardHeader>
            <CardTitle className={`text-lg ${highContrast ? 'text-white' : ''}`}>
              Anomaly Detection
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                {anomaly_detection?.is_anomaly ? (
                  <>
                    <AlertTriangle className="h-5 w-5 text-red-500" aria-hidden="true" />
                    <Badge className={highContrast ? 'bg-red-800 text-white' : 'bg-red-500 text-white'}>
                      Anomaly Detected
                    </Badge>
                  </>
                ) : (
                  <>
                    <CheckCircle className="h-5 w-5 text-green-500" aria-hidden="true" />
                    <Badge className={highContrast ? 'bg-green-700 text-white' : 'bg-green-500 text-white'}>
                      Normal Operation
                    </Badge>
                  </>
                )}
              </div>
              <div className={`text-sm ${highContrast ? 'text-gray-300' : 'text-gray-600'}`}>
                {anomaly_detection?.message || "No anomalies detected"}
              </div>
              {anomaly_detection?.confidence !== undefined && (
                <div className="space-y-2">
                  <div className={`text-xs ${highContrast ? 'text-gray-400' : 'text-gray-500'}`}>
                    Confidence: {Math.round(anomaly_detection.confidence * 100)}%
                  </div>
                  <Progress 
                    value={anomaly_detection.confidence * 100} 
                    className="h-2"
                    aria-label={`Anomaly detection confidence: ${Math.round(anomaly_detection.confidence * 100)} percent`}
                  />
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Maintenance Prediction */}
        <Card className={`lg:col-span-2 ${highContrast ? 'bg-gray-900 border-gray-700' : ''}`}>
          <CardHeader>
            <CardTitle className={`flex items-center gap-2 text-lg ${highContrast ? 'text-white' : ''} ${isRTL ? 'flex-row-reverse' : ''}`}>
              <Wrench className="h-5 w-5" aria-hidden="true" />
              Predictive Maintenance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Risk Score */}
              <div className="space-y-2">
                <div className={`text-sm font-medium ${highContrast ? 'text-gray-300' : 'text-gray-600'}`}>
                  Risk Score
                </div>
                <div className={`text-2xl font-bold ${highContrast ? 'text-white' : ''}`}>
                  {maintenance_prediction?.risk_score || 0}%
                </div>
                <Progress 
                  value={maintenance_prediction?.risk_score || 0} 
                  className="h-2"
                  aria-label={`Maintenance risk score: ${maintenance_prediction?.risk_score || 0} percent`}
                />
              </div>

              {/* Priority */}
              <div className="space-y-2">
                <div className={`text-sm font-medium ${highContrast ? 'text-gray-300' : 'text-gray-600'}`}>
                  Priority Level
                </div>
                <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  {(() => {
                    const IconComponent = getPriorityIcon(maintenance_prediction?.priority)
                    return (
                      <>
                        <IconComponent className="h-4 w-4" aria-hidden="true" />
                        <Badge className={getPriorityColor(maintenance_prediction?.priority)}>
                          {maintenance_prediction?.priority || 'Unknown'}
                        </Badge>
                      </>
                    )
                  })()}
                </div>
              </div>

              {/* Time to Maintenance */}
              <div className="space-y-2">
                <div className={`text-sm font-medium ${highContrast ? 'text-gray-300' : 'text-gray-600'}`}>
                  Estimated Time
                </div>
                <div className={`text-lg font-semibold ${highContrast ? 'text-white' : ''}`}>
                  {maintenance_prediction?.estimated_days_to_maintenance || 'N/A'} days
                </div>
              </div>
            </div>

            {/* Recommendation */}
            <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className={`font-medium text-blue-900 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                AI Recommendation
              </div>
              <div className="text-blue-800 text-sm">
                {maintenance_prediction?.recommendation || "Continue monitoring system performance"}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default AIInsights

