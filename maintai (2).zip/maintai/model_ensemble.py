import numpy as np

def physics_based_model(input_data):
    return np.mean(input_data, axis=1)

def statistical_model(input_data):
    return np.median(input_data, axis=1)

def deep_learning_model(input_data):
    return np.max(input_data, axis=1)

def ensemble_prediction(input_data):
    preds = []
    preds.append(physics_based_model(input_data))
    preds.append(statistical_model(input_data))
    preds.append(deep_learning_model(input_data))
    return np.mean(preds, axis=0)