import numpy as np
from sklearn.neural_network import MLPRegressor

def train_autoencoder(data_matrix):
    model = MLPRegressor(hidden_layer_sizes=(32, 16, 32), max_iter=500)
    model.fit(data_matrix, data_matrix)
    return model

def detect_anomalies(data_matrix):
    model = train_autoencoder(data_matrix)
    reconstructed = model.predict(data_matrix)
    error = np.mean((data_matrix - reconstructed) ** 2, axis=1)
    threshold = np.percentile(error, 95)
    anomalies = [i for i, e in enumerate(error) if e > threshold]
    return anomalies