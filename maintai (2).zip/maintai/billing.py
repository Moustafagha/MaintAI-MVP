def calculate_fee(baseline_downtime, predicted_downtime, actual_downtime, base_fee, cost_per_hour_downtime):
    savings = max(0, baseline_downtime - actual_downtime)
    performance_fee = 0.1 * savings * cost_per_hour_downtime
    return base_fee + performance_fee