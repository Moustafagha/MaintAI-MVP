from cryptography.fernet import Fernet

def generate_key():
    return Fernet.generate_key()

def secure_model(model_path, encryption_key):
    cipher = Fernet(encryption_key)
    with open(model_path, 'rb') as f:
        model_bytes = f.read()
    encrypted_model = cipher.encrypt(model_bytes)
    with open(model_path + '.enc', 'wb') as f:
        f.write(encrypted_model)