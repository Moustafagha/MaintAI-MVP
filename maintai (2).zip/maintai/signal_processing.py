from pykalman import KalmanFilter

def kalman_filter(data_series):
    kf = KalmanFilter(initial_state_mean=0, n_dim_obs=1)
    state_means, _ = kf.filter(data_series)
    return state_means