import numpy as np

def collect_and_normalize(sensor_streams):
    normalized_data = {}
    for sensor_id, stream in sensor_streams.items():
        data = stream
        mean = np.mean(data)
        std = np.std(data)
        normalized_data[sensor_id] = [(x - mean) / std for x in data]
    return normalized_data