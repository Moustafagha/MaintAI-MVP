from sklearn.linear_model import SGDClassifier

def feedback_training(model, new_data, true_labels):
    model.partial_fit(new_data, true_labels, classes=[0, 1])
    return model