import argparse
from maintai import data_collection, pattern_detection

def main():
    parser = argparse.ArgumentParser(description="MaintAI CLI Tool")
    parser.add_argument("--normalize", action="store_true", help="Normalize sample sensor data")
    args = parser.parse_args()

    if args.normalize:
        sample_data = {"sensor1": [10, 12, 13, 12, 11, 14, 15]}
        result = data_collection.collect_and_normalize(sample_data)
        print("Normalized Data:", result)

if __name__ == "__main__":
    main()