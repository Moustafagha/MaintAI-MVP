## Usage

```bash
python -m maintai.cli --normalize
```