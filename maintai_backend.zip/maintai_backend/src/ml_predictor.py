import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import joblib
import os
import sqlite3
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

class MaintAIPredictor:
    def __init__(self, db_path):
        self.db_path = db_path
        self.anomaly_model = None
        self.scaler = StandardScaler()
        self.model_path = os.path.join(os.path.dirname(__file__), '..', 'models')
        os.makedirs(self.model_path, exist_ok=True)
        
        # Define normal operating ranges for each sensor
        self.normal_ranges = {
            'temperature': {'min': 20, 'max': 50},
            'vibration': {'min': 0.1, 'max': 0.8},
            'pressure': {'min': 1.0, 'max': 3.0}
        }
        
        # Load or create models
        self.load_or_create_models()
    
    def get_historical_data(self, days=30):
        """Retrieve historical sensor data from database"""
        try:
            conn = sqlite3.connect(self.db_path)
            
            # Get data from the last 30 days
            cutoff_date = datetime.now() - timedelta(days=days)
            cutoff_timestamp = int(cutoff_date.timestamp())
            
            query = """
            SELECT timestamp, temperature, vibration, pressure 
            FROM sensor_data 
            WHERE timestamp > ?
            ORDER BY timestamp
            """
            
            df = pd.read_sql_query(query, conn, params=(cutoff_timestamp,))
            conn.close()
            
            if len(df) < 10:  # If not enough historical data, generate synthetic data
                df = self.generate_synthetic_data(100)
            
            return df
        except Exception as e:
            print(f"Error retrieving historical data: {e}")
            # Generate synthetic data as fallback
            return self.generate_synthetic_data(100)
    
    def generate_synthetic_data(self, n_samples=100):
        """Generate synthetic sensor data for training when historical data is insufficient"""
        np.random.seed(42)
        
        # Generate normal operating data (80% of samples)
        normal_samples = int(n_samples * 0.8)
        
        normal_temp = np.random.normal(35, 5, normal_samples)
        normal_vib = np.random.normal(0.4, 0.15, normal_samples)
        normal_pres = np.random.normal(2.0, 0.3, normal_samples)
        
        # Generate some anomalous data (20% of samples)
        anomaly_samples = n_samples - normal_samples
        
        anomaly_temp = np.concatenate([
            np.random.normal(70, 5, anomaly_samples // 3),  # High temperature
            np.random.normal(15, 3, anomaly_samples // 3),  # Low temperature
            np.random.normal(35, 5, anomaly_samples - 2 * (anomaly_samples // 3))
        ])
        
        anomaly_vib = np.concatenate([
            np.random.normal(1.2, 0.2, anomaly_samples // 3),  # High vibration
            np.random.normal(0.05, 0.02, anomaly_samples // 3),  # Very low vibration
            np.random.normal(0.4, 0.15, anomaly_samples - 2 * (anomaly_samples // 3))
        ])
        
        anomaly_pres = np.concatenate([
            np.random.normal(4.5, 0.5, anomaly_samples // 3),  # High pressure
            np.random.normal(0.5, 0.1, anomaly_samples // 3),  # Low pressure
            np.random.normal(2.0, 0.3, anomaly_samples - 2 * (anomaly_samples // 3))
        ])
        
        # Combine normal and anomalous data
        temperature = np.concatenate([normal_temp, anomaly_temp])
        vibration = np.concatenate([normal_vib, anomaly_vib])
        pressure = np.concatenate([normal_pres, anomaly_pres])
        
        # Create timestamps
        base_time = int(datetime.now().timestamp()) - (n_samples * 300)  # 5 minutes apart
        timestamps = [base_time + i * 300 for i in range(n_samples)]
        
        df = pd.DataFrame({
            'timestamp': timestamps,
            'temperature': temperature,
            'vibration': vibration,
            'pressure': pressure
        })
        
        return df
    
    def train_anomaly_detection_model(self):
        """Train the anomaly detection model using Isolation Forest"""
        print("Training anomaly detection model...")
        
        # Get historical data
        df = self.get_historical_data()
        
        if len(df) == 0:
            print("No data available for training")
            return False
        
        # Prepare features
        features = df[['temperature', 'vibration', 'pressure']].values
        
        # Scale features
        features_scaled = self.scaler.fit_transform(features)
        
        # Train Isolation Forest for anomaly detection
        self.anomaly_model = IsolationForest(
            contamination=0.1,  # Expect 10% anomalies
            random_state=42,
            n_estimators=100
        )
        
        self.anomaly_model.fit(features_scaled)
        
        # Save models
        self.save_models()
        
        print(f"Model trained on {len(df)} samples")
        return True
    
    def save_models(self):
        """Save trained models to disk"""
        try:
            joblib.dump(self.anomaly_model, os.path.join(self.model_path, 'anomaly_model.pkl'))
            joblib.dump(self.scaler, os.path.join(self.model_path, 'scaler.pkl'))
            print("Models saved successfully")
        except Exception as e:
            print(f"Error saving models: {e}")
    
    def load_models(self):
        """Load trained models from disk"""
        try:
            anomaly_path = os.path.join(self.model_path, 'anomaly_model.pkl')
            scaler_path = os.path.join(self.model_path, 'scaler.pkl')
            
            if os.path.exists(anomaly_path) and os.path.exists(scaler_path):
                self.anomaly_model = joblib.load(anomaly_path)
                self.scaler = joblib.load(scaler_path)
                print("Models loaded successfully")
                return True
            else:
                print("Model files not found")
                return False
        except Exception as e:
            print(f"Error loading models: {e}")
            return False
    
    def load_or_create_models(self):
        """Load existing models or create new ones"""
        if not self.load_models():
            print("Creating new models...")
            self.train_anomaly_detection_model()
    
    def detect_anomaly(self, temperature, vibration, pressure):
        """Detect if current sensor readings are anomalous"""
        if self.anomaly_model is None:
            return {'is_anomaly': False, 'confidence': 0.0, 'message': 'Model not available'}
        
        try:
            # Prepare input data
            features = np.array([[temperature, vibration, pressure]])
            features_scaled = self.scaler.transform(features)
            
            # Predict anomaly (-1 for anomaly, 1 for normal)
            prediction = self.anomaly_model.predict(features_scaled)[0]
            
            # Get anomaly score (lower scores indicate more anomalous)
            anomaly_score = self.anomaly_model.decision_function(features_scaled)[0]
            
            # Convert to confidence (0-1 scale)
            confidence = max(0, min(1, (anomaly_score + 0.5) / 1.0))
            
            is_anomaly = prediction == -1
            
            # Additional rule-based checks
            rule_based_anomaly = self.rule_based_anomaly_check(temperature, vibration, pressure)
            
            # Combine ML and rule-based detection
            final_anomaly = is_anomaly or rule_based_anomaly['is_anomaly']
            
            message = "Normal operation"
            if final_anomaly:
                if rule_based_anomaly['is_anomaly']:
                    message = rule_based_anomaly['message']
                else:
                    message = "Anomalous pattern detected by ML model"
            
            return {
                'is_anomaly': final_anomaly,
                'confidence': confidence,
                'anomaly_score': float(anomaly_score),
                'message': message,
                'ml_prediction': is_anomaly,
                'rule_based': rule_based_anomaly
            }
            
        except Exception as e:
            print(f"Error in anomaly detection: {e}")
            return {'is_anomaly': False, 'confidence': 0.0, 'message': f'Error: {str(e)}'}
    
    def rule_based_anomaly_check(self, temperature, vibration, pressure):
        """Rule-based anomaly detection using predefined thresholds"""
        anomalies = []
        
        # Temperature checks
        if temperature > 65:
            anomalies.append("Critical high temperature")
        elif temperature < 15:
            anomalies.append("Critical low temperature")
        elif temperature > 55:
            anomalies.append("High temperature warning")
        
        # Vibration checks
        if vibration > 1.2:
            anomalies.append("Critical high vibration")
        elif vibration < 0.05:
            anomalies.append("Abnormally low vibration")
        elif vibration > 0.9:
            anomalies.append("High vibration warning")
        
        # Pressure checks
        if pressure > 4.5:
            anomalies.append("Critical high pressure")
        elif pressure < 0.8:
            anomalies.append("Critical low pressure")
        elif pressure > 3.5:
            anomalies.append("High pressure warning")
        
        is_anomaly = len(anomalies) > 0
        message = "; ".join(anomalies) if anomalies else "All parameters within normal range"
        
        return {
            'is_anomaly': is_anomaly,
            'message': message,
            'anomalies': anomalies
        }
    
    def predict_maintenance_need(self, temperature, vibration, pressure):
        """Predict maintenance requirements based on sensor readings"""
        # Get anomaly information
        anomaly_info = self.detect_anomaly(temperature, vibration, pressure)
        
        # Calculate risk score (0-100)
        risk_score = 0
        
        # Temperature risk
        if temperature > 60:
            risk_score += 30
        elif temperature > 50:
            risk_score += 15
        elif temperature < 20:
            risk_score += 20
        
        # Vibration risk
        if vibration > 1.0:
            risk_score += 35
        elif vibration > 0.8:
            risk_score += 20
        elif vibration < 0.1:
            risk_score += 15
        
        # Pressure risk
        if pressure > 4.0:
            risk_score += 25
        elif pressure > 3.0:
            risk_score += 10
        elif pressure < 1.0:
            risk_score += 20
        
        # Adjust based on ML anomaly detection
        if anomaly_info['is_anomaly']:
            risk_score += 20
        
        risk_score = min(100, risk_score)
        
        # Determine maintenance priority
        if risk_score >= 70:
            priority = "Critical"
            recommendation = "Immediate maintenance required"
            estimated_days = 1
        elif risk_score >= 50:
            priority = "High"
            recommendation = "Schedule maintenance within 3 days"
            estimated_days = 3
        elif risk_score >= 30:
            priority = "Medium"
            recommendation = "Schedule maintenance within 1 week"
            estimated_days = 7
        else:
            priority = "Low"
            recommendation = "Continue normal operation"
            estimated_days = 30
        
        return {
            'risk_score': risk_score,
            'priority': priority,
            'recommendation': recommendation,
            'estimated_days_to_maintenance': estimated_days,
            'anomaly_detected': anomaly_info['is_anomaly'],
            'anomaly_details': anomaly_info
        }
    
    def get_system_health_score(self, temperature, vibration, pressure):
        """Calculate overall system health score (0-100)"""
        health_score = 100
        
        # Temperature health impact
        temp_optimal = 35
        temp_deviation = abs(temperature - temp_optimal)
        health_score -= min(30, temp_deviation * 2)
        
        # Vibration health impact
        vib_optimal = 0.3
        vib_deviation = abs(vibration - vib_optimal)
        health_score -= min(25, vib_deviation * 50)
        
        # Pressure health impact
        pres_optimal = 2.0
        pres_deviation = abs(pressure - pres_optimal)
        health_score -= min(20, pres_deviation * 10)
        
        # Anomaly impact
        anomaly_info = self.detect_anomaly(temperature, vibration, pressure)
        if anomaly_info['is_anomaly']:
            health_score -= 25
        
        return max(0, min(100, health_score))

