from flask import Blueprint, jsonify, request
from flask_cors import cross_origin
import sqlite3
import os
from src.nlp_assistant import MaintAINLPAssistant

nlp_bp = Blueprint('nlp', __name__)

# Initialize NLP assistant
nlp_assistant = MaintAINLPAssistant()

def get_db_connection():
    db_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'database', 'maintai_logs.db')
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def get_latest_sensor_data():
    """Get the most recent sensor data for context"""
    try:
        conn = get_db_connection()
        cursor = conn.execute('''
            SELECT temperature, vibration, pressure 
            FROM sensor_data 
            ORDER BY timestamp DESC 
            LIMIT 1
        ''')
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return {
                'temperature': row['temperature'],
                'vibration': row['vibration'],
                'pressure': row['pressure']
            }
        return None
    except Exception as e:
        print(f"Error getting sensor data: {e}")
        return None

@nlp_bp.route('/ask', methods=['POST'])
@cross_origin()
def ask_assistant():
    """Ask the NLP assistant a question"""
    try:
        data = request.get_json()
        query = data.get('question', '').strip()
        
        if not query:
            return jsonify({
                'status': 'error',
                'message': 'Question is required'
            }), 400
        
        # Get current sensor data for context
        sensor_data = get_latest_sensor_data()
        
        # Generate response
        response_data = nlp_assistant.generate_response(query, sensor_data)
        
        return jsonify({
            'status': 'success',
            'query': query,
            'response': response_data['response'],
            'intent': response_data['intent'],
            'confidence': response_data['confidence'],
            'timestamp': response_data['timestamp'],
            'has_context': response_data['has_context']
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@nlp_bp.route('/suggestions', methods=['GET'])
@cross_origin()
def get_suggestions():
    """Get suggested questions for the user"""
    try:
        suggestions = nlp_assistant.get_suggested_questions()
        
        return jsonify({
            'status': 'success',
            'suggestions': suggestions
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@nlp_bp.route('/chat/history', methods=['GET'])
@cross_origin()
def get_chat_history():
    """Get chat history (placeholder for future implementation)"""
    try:
        # For now, return empty history
        # In a real implementation, you would store and retrieve chat history
        return jsonify({
            'status': 'success',
            'history': [],
            'message': 'Chat history feature coming soon'
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@nlp_bp.route('/chat/clear', methods=['POST'])
@cross_origin()
def clear_chat_history():
    """Clear chat history (placeholder for future implementation)"""
    try:
        return jsonify({
            'status': 'success',
            'message': 'Chat history cleared'
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@nlp_bp.route('/help', methods=['GET'])
@cross_origin()
def get_help():
    """Get help information about the NLP assistant"""
    try:
        help_info = {
            'description': 'MaintAI NLP Assistant - Your intelligent maintenance companion',
            'capabilities': [
                'Answer questions about sensor readings and system status',
                'Provide AI insights and maintenance recommendations',
                'Explain dashboard features and accessibility options',
                'Offer troubleshooting guidance and support',
                'Interpret anomaly detection results',
                'Suggest maintenance schedules and priorities'
            ],
            'example_questions': nlp_assistant.get_suggested_questions(),
            'supported_topics': [
                'System status and health',
                'Sensor readings (temperature, vibration, pressure)',
                'AI and machine learning insights',
                'Maintenance and scheduling',
                'Alerts and warnings',
                'Dashboard features and navigation',
                'Troubleshooting and support'
            ]
        }
        
        return jsonify({
            'status': 'success',
            'help': help_info
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

