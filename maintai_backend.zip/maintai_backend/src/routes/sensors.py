from flask import Blueprint, jsonify, request
from flask_cors import cross_origin
import random
import sqlite3
import time
import os
import numpy as np
from src.ml_predictor import MaintAIPredictor

def convert_numpy_types(obj):
    """Convert numpy types to Python native types for JSON serialization"""
    if isinstance(obj, dict):
        return {key: convert_numpy_types(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        return [convert_numpy_types(item) for item in obj]
    elif isinstance(obj, np.bool_):
        return bool(obj)
    elif isinstance(obj, np.integer):
        return int(obj)
    elif isinstance(obj, np.floating):
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    else:
        return obj

sensors_bp = Blueprint('sensors', __name__)

# Initialize ML predictor
db_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'database', 'maintai_logs.db')
ml_predictor = MaintAIPredictor(db_path)

# Database setup
def get_db_connection():
    db_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'database', 'maintai_logs.db')
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def init_sensors_db():
    conn = get_db_connection()
    conn.execute('''
    CREATE TABLE IF NOT EXISTS sensor_data (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp INTEGER,
        temperature REAL,
        vibration REAL,
        pressure REAL
    )
    ''')
    conn.commit()
    conn.close()

def insert_data(temp, vib, pres):
    timestamp = int(time.time())
    conn = get_db_connection()
    conn.execute(
        'INSERT INTO sensor_data (timestamp, temperature, vibration, pressure) VALUES (?, ?, ?, ?)',
        (timestamp, temp, vib, pres)
    )
    conn.commit()
    conn.close()

@sensors_bp.route('/sensors', methods=['GET'])
@cross_origin()
def get_sensors():
    """Get current sensor readings with AI/ML analysis"""
    temp = round(random.uniform(20.0, 80.0), 2)
    vib = round(random.uniform(0.1, 1.5), 2)
    pres = round(random.uniform(1.0, 5.0), 2)
    
    # Insert data into database
    insert_data(temp, vib, pres)
    
    # Get AI/ML predictions
    try:
        anomaly_info = ml_predictor.detect_anomaly(temp, vib, pres)
        maintenance_prediction = ml_predictor.predict_maintenance_need(temp, vib, pres)
        health_score = ml_predictor.get_system_health_score(temp, vib, pres)
        
        ai_analysis = convert_numpy_types({
            'anomaly_detection': anomaly_info,
            'maintenance_prediction': maintenance_prediction,
            'health_score': round(health_score, 1)
        })
    except Exception as e:
        print(f"Error in AI analysis: {e}")
        ai_analysis = {
            'anomaly_detection': {'is_anomaly': False, 'message': 'AI analysis unavailable'},
            'maintenance_prediction': {'priority': 'Unknown', 'recommendation': 'AI analysis unavailable'},
            'health_score': 85.0
        }
    
    return jsonify({
        "temperature": temp,
        "vibration": vib,
        "pressure": pres,
        "ai_analysis": ai_analysis,
        "timestamp": int(time.time())
    })

@sensors_bp.route('/predict', methods=['POST'])
@cross_origin()
def predict_status():
    """Predict system status based on provided sensor values"""
    try:
        data = request.get_json()
        temp = float(data.get('temperature', 0))
        vib = float(data.get('vibration', 0))
        pres = float(data.get('pressure', 0))
        
        # Get AI/ML predictions
        anomaly_info = ml_predictor.detect_anomaly(temp, vib, pres)
        maintenance_prediction = ml_predictor.predict_maintenance_need(temp, vib, pres)
        health_score = ml_predictor.get_system_health_score(temp, vib, pres)
        
        return jsonify({
            'status': 'success',
            'predictions': convert_numpy_types({
                'anomaly_detection': anomaly_info,
                'maintenance_prediction': maintenance_prediction,
                'health_score': round(health_score, 1)
            }),
            'input_values': {
                'temperature': temp,
                'vibration': vib,
                'pressure': pres
            }
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 400

@sensors_bp.route('/health', methods=['GET'])
@cross_origin()
def get_system_health():
    """Get overall system health metrics"""
    try:
        # Get recent sensor data
        conn = get_db_connection()
        cursor = conn.execute('''
            SELECT temperature, vibration, pressure 
            FROM sensor_data 
            ORDER BY timestamp DESC 
            LIMIT 10
        ''')
        recent_data = cursor.fetchall()
        conn.close()
        
        if not recent_data:
            return jsonify({
                'status': 'error',
                'message': 'No sensor data available'
            }), 404
        
        # Calculate average health score from recent readings
        health_scores = []
        anomaly_count = 0
        
        for row in recent_data:
            temp, vib, pres = row['temperature'], row['vibration'], row['pressure']
            health_score = ml_predictor.get_system_health_score(temp, vib, pres)
            health_scores.append(health_score)
            
            anomaly_info = ml_predictor.detect_anomaly(temp, vib, pres)
            if anomaly_info['is_anomaly']:
                anomaly_count += 1
        
        avg_health_score = sum(health_scores) / len(health_scores)
        anomaly_rate = (anomaly_count / len(recent_data)) * 100
        
        # Determine overall system status
        if avg_health_score >= 80:
            system_status = "Excellent"
        elif avg_health_score >= 60:
            system_status = "Good"
        elif avg_health_score >= 40:
            system_status = "Fair"
        else:
            system_status = "Poor"
        
        return jsonify({
            'status': 'success',
            'health_metrics': {
                'average_health_score': round(avg_health_score, 1),
                'system_status': system_status,
                'anomaly_rate': round(anomaly_rate, 1),
                'samples_analyzed': len(recent_data),
                'trend': 'stable'  # Could be enhanced with trend analysis
            }
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@sensors_bp.route('/retrain', methods=['POST'])
@cross_origin()
def retrain_model():
    """Retrain the ML model with latest data"""
    try:
        success = ml_predictor.train_anomaly_detection_model()
        
        if success:
            return jsonify({
                'status': 'success',
                'message': 'Model retrained successfully'
            })
        else:
            return jsonify({
                'status': 'error',
                'message': 'Failed to retrain model'
            }), 500
            
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@sensors_bp.route('/historical', methods=['GET'])
@cross_origin()
def get_historical_data():
    """Get historical sensor data for analysis"""
    try:
        days = request.args.get('days', 7, type=int)
        limit = request.args.get('limit', 100, type=int)
        
        conn = get_db_connection()
        cursor = conn.execute('''
            SELECT timestamp, temperature, vibration, pressure 
            FROM sensor_data 
            ORDER BY timestamp DESC 
            LIMIT ?
        ''', (limit,))
        
        data = []
        for row in cursor.fetchall():
            data.append({
                'timestamp': row['timestamp'],
                'temperature': row['temperature'],
                'vibration': row['vibration'],
                'pressure': row['pressure']
            })
        
        conn.close()
        
        return jsonify({
            'status': 'success',
            'data': data,
            'count': len(data)
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

# Initialize database when module is imported
init_sensors_db()

