from flask import Blueprint, jsonify, request
from flask_cors import cross_origin
import random
import sqlite3
import time
import os

sensors_bp = Blueprint('sensors', __name__)

# Database setup
def get_db_connection():
    db_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'database', 'maintai_logs.db')
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def init_database():
    conn = get_db_connection()
    conn.execute('''
        CREATE TABLE IF NOT EXISTS sensor_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp INTEGER,
            temperature REAL,
            vibration REAL,
            pressure REAL
        )
    ''')
    conn.commit()
    conn.close()

# Initialize database
init_database()

def insert_data(temp, vib, pres):
    conn = get_db_connection()
    timestamp = int(time.time())
    conn.execute(
        'INSERT INTO sensor_data (timestamp, temperature, vibration, pressure) VALUES (?, ?, ?, ?)',
        (timestamp, temp, vib, pres)
    )
    conn.commit()
    conn.close()

def rule_based_anomaly_detection(temp, vib, pres):
    """Simple rule-based anomaly detection"""
    anomalies = []
    
    if temp > 60:
        anomalies.append("Critical high temperature")
    elif temp > 50:
        anomalies.append("High temperature warning")
    elif temp < 10:
        anomalies.append("Low temperature warning")
    
    if vib > 1.0:
        anomalies.append("Critical vibration levels")
    elif vib > 0.8:
        anomalies.append("High vibration warning")
    
    if pres > 4.0:
        anomalies.append("Critical high pressure")
    elif pres > 3.0:
        anomalies.append("High pressure warning")
    elif pres < 1.0:
        anomalies.append("Low pressure warning")
    
    is_anomaly = len(anomalies) > 0
    message = "; ".join(anomalies) if anomalies else "All parameters within normal range"
    
    return {
        "is_anomaly": is_anomaly,
        "message": message,
        "anomalies": anomalies,
        "confidence": 0.9 if is_anomaly else 0.95,
        "anomaly_score": len(anomalies) * 0.3
    }

def calculate_health_score(temp, vib, pres):
    """Calculate system health score based on sensor readings"""
    score = 100
    
    # Temperature impact
    if temp > 60:
        score -= 40
    elif temp > 50:
        score -= 20
    elif temp > 40:
        score -= 10
    
    # Vibration impact
    if vib > 1.0:
        score -= 30
    elif vib > 0.8:
        score -= 15
    elif vib > 0.6:
        score -= 8
    
    # Pressure impact
    if pres > 4.0:
        score -= 25
    elif pres > 3.0:
        score -= 12
    elif pres < 1.0:
        score -= 15
    
    return max(0, score)

def predict_maintenance(temp, vib, pres, anomaly_info):
    """Predict maintenance needs based on sensor data"""
    risk_score = 0
    priority = "Low"
    days_to_maintenance = 30
    
    # Calculate risk based on anomalies
    if anomaly_info["is_anomaly"]:
        risk_score = min(100, len(anomaly_info["anomalies"]) * 25 + 25)
        
        if risk_score >= 75:
            priority = "Critical"
            days_to_maintenance = 1
        elif risk_score >= 50:
            priority = "High"
            days_to_maintenance = 3
        elif risk_score >= 25:
            priority = "Medium"
            days_to_maintenance = 7
    else:
        risk_score = 10
        priority = "Low"
        days_to_maintenance = 30
    
    recommendation = {
        "Critical": "Immediate maintenance required",
        "High": "Schedule maintenance within 3 days",
        "Medium": "Schedule maintenance within a week",
        "Low": "Regular maintenance schedule"
    }.get(priority, "Monitor system")
    
    return {
        "priority": priority,
        "risk_score": risk_score,
        "estimated_days_to_maintenance": days_to_maintenance,
        "recommendation": recommendation,
        "anomaly_detected": anomaly_info["is_anomaly"],
        "anomaly_details": anomaly_info
    }

@sensors_bp.route('/sensors', methods=['GET'])
@cross_origin()
def get_sensors():
    # Generate random sensor data
    temp = round(random.uniform(20.0, 80.0), 2)
    vib = round(random.uniform(0.1, 1.5), 2)
    pres = round(random.uniform(1.0, 5.0), 2)
    
    # Store data
    insert_data(temp, vib, pres)
    
    try:
        # Rule-based AI analysis
        anomaly_info = rule_based_anomaly_detection(temp, vib, pres)
        maintenance_prediction = predict_maintenance(temp, vib, pres, anomaly_info)
        health_score = calculate_health_score(temp, vib, pres)
        
        ai_analysis = {
            'anomaly_detection': anomaly_info,
            'maintenance_prediction': maintenance_prediction,
            'health_score': round(health_score, 1)
        }
    except Exception as e:
        print(f"Error in AI analysis: {e}")
        ai_analysis = {
            'anomaly_detection': {'is_anomaly': False, 'message': 'AI analysis unavailable'},
            'maintenance_prediction': {'priority': 'Unknown', 'recommendation': 'AI analysis unavailable'},
            'health_score': 85.0
        }
    
    return jsonify({
        "temperature": temp,
        "vibration": vib,
        "pressure": pres,
        "ai_analysis": ai_analysis,
        "timestamp": int(time.time())
    })

@sensors_bp.route('/predict', methods=['POST'])
@cross_origin()
def predict_status():
    try:
        data = request.get_json()
        temp = float(data.get('temperature', 25))
        vib = float(data.get('vibration', 0.5))
        pres = float(data.get('pressure', 2.0))
        
        # Rule-based analysis
        anomaly_info = rule_based_anomaly_detection(temp, vib, pres)
        maintenance_prediction = predict_maintenance(temp, vib, pres, anomaly_info)
        health_score = calculate_health_score(temp, vib, pres)
        
        return jsonify({
            'status': 'success',
            'predictions': {
                'anomaly_detection': anomaly_info,
                'maintenance_prediction': maintenance_prediction,
                'health_score': round(health_score, 1)
            },
            'input_values': {
                'temperature': temp,
                'vibration': vib,
                'pressure': pres
            }
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@sensors_bp.route('/history', methods=['GET'])
@cross_origin()
def get_sensor_history():
    try:
        limit = request.args.get('limit', 100, type=int)
        
        conn = get_db_connection()
        cursor = conn.execute('''
            SELECT * FROM sensor_data 
            ORDER BY timestamp DESC 
            LIMIT ?
        ''', (limit,))
        
        rows = cursor.fetchall()
        conn.close()
        
        history = []
        for row in rows:
            history.append({
                'id': row['id'],
                'timestamp': row['timestamp'],
                'temperature': row['temperature'],
                'vibration': row['vibration'],
                'pressure': row['pressure']
            })
        
        return jsonify({
            'status': 'success',
            'history': history,
            'count': len(history)
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

