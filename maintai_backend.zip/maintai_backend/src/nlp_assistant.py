import re
import json
from datetime import datetime
from typing import Dict, List, Any

class MaintAINLPAssistant:
    def __init__(self):
        self.knowledge_base = {
            # System information
            "system_info": {
                "patterns": [
                    r"what.*system.*status",
                    r"how.*system.*working",
                    r"system.*health",
                    r"overall.*status",
                    r"equipment.*status"
                ],
                "responses": [
                    "The system is currently operational with all sensors reporting within acceptable ranges.",
                    "System health is being monitored in real-time through temperature, vibration, and pressure sensors.",
                    "Our AI-powered monitoring system continuously analyzes sensor data for anomalies and maintenance needs."
                ]
            },
            
            # Sensor information
            "sensors": {
                "patterns": [
                    r"what.*sensors",
                    r"sensor.*types",
                    r"monitoring.*what",
                    r"measure.*what",
                    r"track.*parameters"
                ],
                "responses": [
                    "We monitor three key parameters: temperature (°C), vibration (g), and pressure (bar).",
                    "The system tracks temperature, vibration, and pressure sensors to ensure optimal equipment performance.",
                    "Our sensors provide real-time data on temperature, vibration levels, and pressure readings."
                ]
            },
            
            # Temperature
            "temperature": {
                "patterns": [
                    r"temperature.*normal",
                    r"temp.*range",
                    r"hot.*cold",
                    r"degrees.*celsius",
                    r"thermal.*monitoring"
                ],
                "responses": [
                    "Normal temperature range is 20-50°C. Values above 60°C are critical and require immediate attention.",
                    "Temperature monitoring helps detect overheating issues that could lead to equipment failure.",
                    "We track temperature to prevent thermal damage and ensure optimal operating conditions."
                ]
            },
            
            # Vibration
            "vibration": {
                "patterns": [
                    r"vibration.*normal",
                    r"shake.*movement",
                    r"oscillation",
                    r"mechanical.*stress",
                    r"g.*force"
                ],
                "responses": [
                    "Normal vibration levels are below 0.5g. High vibration (>1.0g) indicates mechanical issues.",
                    "Vibration monitoring detects bearing wear, misalignment, and other mechanical problems.",
                    "Excessive vibration can lead to equipment damage and should be addressed promptly."
                ]
            },
            
            # Pressure
            "pressure": {
                "patterns": [
                    r"pressure.*normal",
                    r"bar.*reading",
                    r"hydraulic.*pneumatic",
                    r"pressure.*system",
                    r"fluid.*pressure"
                ],
                "responses": [
                    "Normal pressure range is 1.0-3.0 bar. Values above 4.0 bar are critical.",
                    "Pressure monitoring ensures proper fluid system operation and prevents damage.",
                    "Abnormal pressure readings can indicate leaks, blockages, or pump issues."
                ]
            },
            
            # AI and ML
            "ai_ml": {
                "patterns": [
                    r"ai.*work",
                    r"machine.*learning",
                    r"artificial.*intelligence",
                    r"predict.*maintenance",
                    r"anomaly.*detection",
                    r"ml.*model"
                ],
                "responses": [
                    "Our AI system uses machine learning to detect anomalies and predict maintenance needs.",
                    "The ML model analyzes sensor patterns to identify potential issues before they become critical.",
                    "AI-powered predictive maintenance helps reduce downtime and optimize maintenance schedules."
                ]
            },
            
            # Maintenance
            "maintenance": {
                "patterns": [
                    r"maintenance.*schedule",
                    r"when.*maintain",
                    r"service.*required",
                    r"repair.*needed",
                    r"preventive.*maintenance"
                ],
                "responses": [
                    "Maintenance scheduling is based on AI predictions and sensor data analysis.",
                    "Preventive maintenance helps avoid unexpected failures and extends equipment life.",
                    "The system provides maintenance recommendations based on current conditions and historical data."
                ]
            },
            
            # Alerts and warnings
            "alerts": {
                "patterns": [
                    r"alert.*warning",
                    r"notification.*system",
                    r"alarm.*trigger",
                    r"critical.*status",
                    r"emergency.*response"
                ],
                "responses": [
                    "The system provides real-time alerts for critical conditions and anomalies.",
                    "Alerts are color-coded: green (normal), yellow (warning), red (critical).",
                    "Immediate notifications help operators respond quickly to potential issues."
                ]
            },
            
            # Dashboard features
            "dashboard": {
                "patterns": [
                    r"dashboard.*features",
                    r"interface.*use",
                    r"navigation.*help",
                    r"accessibility.*support",
                    r"language.*support"
                ],
                "responses": [
                    "The dashboard supports multiple languages, high contrast mode, and keyboard navigation.",
                    "Features include real-time monitoring, AI insights, and accessibility enhancements.",
                    "The interface is designed for users with different abilities and language preferences."
                ]
            },
            
            # Troubleshooting
            "troubleshooting": {
                "patterns": [
                    r"problem.*issue",
                    r"not.*working",
                    r"error.*fix",
                    r"troubleshoot",
                    r"help.*support"
                ],
                "responses": [
                    "For technical issues, check sensor connections and refresh the data.",
                    "If problems persist, contact technical support or check the system logs.",
                    "Common issues include sensor disconnection or network connectivity problems."
                ]
            },
            
            # General help
            "help": {
                "patterns": [
                    r"help.*me",
                    r"how.*use",
                    r"getting.*started",
                    r"tutorial.*guide",
                    r"instructions"
                ],
                "responses": [
                    "I can help you understand the monitoring system, sensor readings, and AI insights.",
                    "Ask me about sensors, maintenance, alerts, or any dashboard features.",
                    "I'm here to assist with system information and troubleshooting guidance."
                ]
            }
        }
        
        # Greeting patterns
        self.greetings = {
            "patterns": [
                r"hello.*hi.*hey",
                r"good.*morning.*afternoon.*evening",
                r"greetings",
                r"start.*conversation"
            ],
            "responses": [
                "Hello! I'm your MaintAI assistant. How can I help you today?",
                "Hi there! I can answer questions about the monitoring system and maintenance.",
                "Greetings! Ask me anything about sensors, AI insights, or system status."
            ]
        }
        
        # Farewell patterns
        self.farewells = {
            "patterns": [
                r"bye.*goodbye.*farewell",
                r"see.*you.*later",
                r"thanks.*thank.*you",
                r"that.*all.*enough"
            ],
            "responses": [
                "Goodbye! Feel free to ask if you need more assistance.",
                "Thank you for using MaintAI. Have a great day!",
                "See you later! I'm always here to help with your monitoring needs."
            ]
        }
    
    def preprocess_query(self, query: str) -> str:
        """Clean and normalize the user query"""
        # Convert to lowercase
        query = query.lower().strip()
        
        # Remove extra whitespace
        query = re.sub(r'\s+', ' ', query)
        
        # Remove punctuation except for important ones
        query = re.sub(r'[^\w\s\?\!\.]', ' ', query)
        
        return query
    
    def find_intent(self, query: str) -> tuple:
        """Find the intent and confidence score for the query"""
        query = self.preprocess_query(query)
        
        # Check greetings first
        for pattern in self.greetings["patterns"]:
            if re.search(pattern, query):
                return "greeting", 0.9
        
        # Check farewells
        for pattern in self.farewells["patterns"]:
            if re.search(pattern, query):
                return "farewell", 0.9
        
        # Check knowledge base
        best_match = None
        best_score = 0
        
        for intent, data in self.knowledge_base.items():
            for pattern in data["patterns"]:
                if re.search(pattern, query):
                    # Simple scoring based on pattern match
                    score = len(re.findall(pattern, query)) * 0.8
                    if score > best_score:
                        best_score = score
                        best_match = intent
        
        return best_match, best_score
    
    def get_contextual_response(self, intent: str, sensor_data: Dict = None) -> str:
        """Generate contextual response based on current sensor data"""
        if not sensor_data:
            return self.get_generic_response(intent)
        
        # Add context based on current sensor readings
        temp = sensor_data.get('temperature', 0)
        vib = sensor_data.get('vibration', 0)
        pres = sensor_data.get('pressure', 0)
        ai_analysis = sensor_data.get('ai_analysis', {})
        
        if intent == "system_info":
            health_score = ai_analysis.get('health_score', 85)
            if health_score >= 80:
                return f"The system is in excellent condition with a health score of {health_score}%. All sensors are operating normally."
            elif health_score >= 60:
                return f"The system is in good condition with a health score of {health_score}%. Minor monitoring recommended."
            else:
                return f"The system health score is {health_score}%. Please review the AI insights for recommendations."
        
        elif intent == "temperature":
            if temp > 60:
                return f"Current temperature is {temp}°C, which is in the critical range. Immediate cooling action recommended."
            elif temp > 50:
                return f"Current temperature is {temp}°C, showing warning levels. Monitor closely for further increases."
            else:
                return f"Current temperature is {temp}°C, which is within normal operating range."
        
        elif intent == "vibration":
            if vib > 1.0:
                return f"Current vibration level is {vib}g, indicating critical mechanical stress. Inspection required."
            elif vib > 0.8:
                return f"Current vibration level is {vib}g, showing elevated levels. Check for mechanical issues."
            else:
                return f"Current vibration level is {vib}g, which is within acceptable limits."
        
        elif intent == "pressure":
            if pres > 4.0:
                return f"Current pressure is {pres} bar, which is critically high. Check for system blockages."
            elif pres > 3.0:
                return f"Current pressure is {pres} bar, showing warning levels. Monitor system performance."
            else:
                return f"Current pressure is {pres} bar, operating within normal parameters."
        
        elif intent == "ai_ml":
            anomaly_detected = ai_analysis.get('anomaly_detection', {}).get('is_anomaly', False)
            if anomaly_detected:
                return "The AI system has detected an anomaly in the current sensor readings. Please check the AI Insights tab for detailed analysis."
            else:
                return "The AI system shows normal operation patterns. Predictive maintenance recommendations are available in the AI Insights section."
        
        return self.get_generic_response(intent)
    
    def get_generic_response(self, intent: str) -> str:
        """Get a generic response for the given intent"""
        if intent == "greeting":
            return self.greetings["responses"][0]
        elif intent == "farewell":
            return self.farewells["responses"][0]
        elif intent in self.knowledge_base:
            return self.knowledge_base[intent]["responses"][0]
        else:
            return "I'm not sure about that. Could you ask about sensors, maintenance, AI insights, or system status?"
    
    def generate_response(self, query: str, sensor_data: Dict = None) -> Dict[str, Any]:
        """Generate a complete response to the user query"""
        intent, confidence = self.find_intent(query)
        
        if confidence < 0.3:
            response_text = "I'm not sure I understand. You can ask me about:\n" \
                          "• Sensor readings and status\n" \
                          "• AI insights and predictions\n" \
                          "• Maintenance recommendations\n" \
                          "• System health and alerts\n" \
                          "• Dashboard features and help"
            intent = "unknown"
        else:
            response_text = self.get_contextual_response(intent, sensor_data)
        
        return {
            "response": response_text,
            "intent": intent,
            "confidence": confidence,
            "timestamp": datetime.now().isoformat(),
            "has_context": sensor_data is not None
        }
    
    def get_suggested_questions(self) -> List[str]:
        """Get a list of suggested questions users can ask"""
        return [
            "What is the current system status?",
            "How are the sensors performing?",
            "What does the AI analysis show?",
            "When is maintenance needed?",
            "Are there any alerts or warnings?",
            "How does the anomaly detection work?",
            "What are the normal sensor ranges?",
            "How can I use the dashboard features?"
        ]

